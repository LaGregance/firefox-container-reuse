#!/bin/sh
web-ext build --ignore-files "*.sh"
# Container Reuse

This extension add an additional feature to Firefox Multi-Account Containers: when you open a new empty tab,
it will reuse the container of the previous active tab.

It help to keep environment separated will maintaining navigation easy, mainly for separate work & personal stuff.

## Development

Go to `about:debugging` -> This Firefox -> Load Temporary Add-on (select `manifest.json`).  
To see log: Tools -> Browser Tools -> Browser Console (CMD+MAJ+J) -> Select Multiprocess

## Release (Beta - GitHub)


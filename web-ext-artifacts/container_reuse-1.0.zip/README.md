# Container Reuse

This extension add an additional feature to Firefox Multi-Account Containers: when you open a new empty tab,
it will reuse the container of the previous active tab.

It help to keep environment separated will maintaining navigation easy, mainly for separate work & personal stuff.